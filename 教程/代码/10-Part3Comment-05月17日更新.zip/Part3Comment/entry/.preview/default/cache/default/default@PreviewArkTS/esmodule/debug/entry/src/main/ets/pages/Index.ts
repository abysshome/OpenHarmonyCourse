interface Index_Params {
    commentList?: CommentData[];
}
import InfoTop from "@bundle:com.example.part3comment/entry/ets/components/InfoTop";
import InfoItem from "@bundle:com.example.part3comment/entry/ets/components/InfoItem";
import InfoBottom from "@bundle:com.example.part3comment/entry/ets/components/InfoBottom";
import font from "@ohos:font";
import { CommentData, createListRange } from "@bundle:com.example.part3comment/entry/ets/model/CommentData";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__commentList = new ObservedPropertyObjectPU(createListRange()
        // 一加载Index入口页面, 就进行注册
        // aboutToAppear → 会在组件一加载时, 自动调用执行(生命周期函数)
        , this, "commentList");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.commentList !== undefined) {
            this.commentList = params.commentList;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__commentList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__commentList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __commentList: ObservedPropertyObjectPU<CommentData[]>;
    get commentList() {
        return this.__commentList.get();
    }
    set commentList(newValue: CommentData[]) {
        this.__commentList.set(newValue);
    }
    // 一加载Index入口页面, 就进行注册
    // aboutToAppear → 会在组件一加载时, 自动调用执行(生命周期函数)
    aboutToAppear(): void {
        // 1. 注册字体
        font.registerFont({
            familyName: 'myfont',
            familySrc: '/fonts/iconfont.ttf'
        });
        this.handleSort(0);
    }
    // 处理喜欢
    handleLike(index: number) {
        // 1. 获取下标 或 id 加以区分
        // 子调用父的方法时, 每个子都能调用父的方法, 需要加以区分
        // 此时由于是数组操作, 可以传递下标, [快速定位到操作的是哪项]
        // 将来发请求 → id 作为区分值, 也可以
        // AlertDialog.show({
        //   message: index.toString()
        // })
        // 2. 父组件的方法, 如果抽取出来, 如果直接传递给子组件
        //    会有 this 指向问题, this 通常直接指向调用者
        //    需要, 用箭头函数函数包一层, 保证 this 还是指向父组件
        //    console.log('父组件的数据', this.commentList)
        // 3. 根据 index, 根据 数组数据, 进行判断 +1 还是 -1
        let itemData = this.commentList[index];
        if (itemData.isLike) {
            itemData.likeNum -= 1;
        }
        else {
            itemData.likeNum += 1;
        }
        itemData.isLike = !itemData.isLike;
        // 4. 对于复杂类型: 状态对象, 状态数组, 只会对第一层数据, 进行监视变化
        // 数组.splice(从哪开始删除, 删除几个, 替换的项1, 替换的项2, ...)
        this.commentList.splice(index, 1, itemData);
    }
    // 处理提交
    handleSubmit(content: string) {
        // 往数组的最前面, 新增一项
        const newItem: CommentData = new CommentData("https://img0.baidu.com/it/u=3316636492,2799302396&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1708707600&t=fc2a4907d0fae5c7b2d2d5f1511c24b3", "我", new Date().getTime(), 5, 0, content, false);
        this.commentList = [newItem, ...this.commentList];
    }
    // 处理排序 0 最新 time时间戳,  1 最热 likeCount 点赞数
    handleSort(type: number) {
        if (type === 0) {
            // 时间戳, 从大到小排序
            this.commentList.sort((a, b) => {
                // a 前一项, b 后一项
                return b.time - a.time; // 返回值如果 > 0, 交换位置
            });
        }
        else {
            // 点赞数, 从大到小排序
            this.commentList.sort((a, b) => {
                return b.likeNum - a.likeNum;
            });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(92:5)");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // 2. 使用字体测试
                    // Text('\ue600')
                    //   .fontFamily('myfont')
                    //   .fontSize(30)
                    //   .fontColor(Color.Red)
                    // 头部标题组件
                    InfoTop(this, {
                        onSort: (type: number) => {
                            this.handleSort(type);
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 100 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            onSort: (type: number) => {
                                this.handleSort(type);
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "InfoTop" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 中间
            List.create();
            List.debugLine("entry/src/main/ets/pages/Index.ets(107:7)");
            // 中间
            List.layoutWeight(1);
            // 中间
            List.padding({ bottom: 10 });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/Index.ets(109:11)");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new 
                                    // 列表项组件 - 将item对象, 通过prop传值, 传递下去
                                    InfoItem(this, {
                                        index: index,
                                        itemObj: item,
                                        onLikeClick: (index: number) => {
                                            // 此处的this → 访问的是外部环境的 this → 就是父组件
                                            this.handleLike(index);
                                        }
                                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 111 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            index: index,
                                            itemObj: item,
                                            onLikeClick: (index: number) => {
                                                // 此处的this → 访问的是外部环境的 this → 就是父组件
                                                this.handleLike(index);
                                            }
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        index: index,
                                        itemObj: item
                                    });
                                }
                            }, { name: "InfoItem" });
                        }
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.commentList, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // 中间
        List.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // 底部
                    InfoBottom(this, {
                        onSubmitComment: (content: string) => {
                            this.handleSubmit(content);
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 126 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            onSubmitComment: (content: string) => {
                                this.handleSubmit(content);
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "InfoBottom" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.part3comment", moduleName: "entry", pagePath: "pages/Index" });
