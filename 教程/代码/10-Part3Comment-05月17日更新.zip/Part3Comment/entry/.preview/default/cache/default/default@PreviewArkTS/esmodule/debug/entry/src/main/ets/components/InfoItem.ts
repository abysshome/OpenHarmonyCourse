interface InfoItem_Params {
    itemObj?: CommentData;
    index?: number;
    onLikeClick?;
}
import type { CommentData } from '../model/CommentData';
class InfoItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__itemObj = new SynchedPropertyObjectOneWayPU(params.itemObj, this, "itemObj");
        this.__index = new SynchedPropertySimpleOneWayPU(params.index, this, "index");
        this.onLikeClick = (index: number) => { };
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: InfoItem_Params) {
        if (params.onLikeClick !== undefined) {
            this.onLikeClick = params.onLikeClick;
        }
    }
    updateStateVars(params: InfoItem_Params) {
        this.__itemObj.reset(params.itemObj);
        this.__index.reset(params.index);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__itemObj.purgeDependencyOnElmtId(rmElmtId);
        this.__index.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__itemObj.aboutToBeDeleted();
        this.__index.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __itemObj: SynchedPropertySimpleOneWayPU<CommentData>;
    get itemObj() {
        return this.__itemObj.get();
    }
    set itemObj(newValue: CommentData) {
        this.__itemObj.set(newValue);
    }
    private __index: SynchedPropertySimpleOneWayPU<number>;
    get index() {
        return this.__index.get();
    }
    set index(newValue: number) {
        this.__index.set(newValue);
    }
    private onLikeClick;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/InfoItem.ets(10:5)");
            Column.padding({ left: 15, right: 15 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 1. 头像, 昵称, 等级
            Row.create();
            Row.debugLine("entry/src/main/ets/components/InfoItem.ets(12:7)");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.itemObj.avatar);
            Image.debugLine("entry/src/main/ets/components/InfoItem.ets(13:9)");
            Image.width(30);
            Image.aspectRatio(1);
            Image.margin({ top: 10 });
            Image.borderRadius(15);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemObj.name);
            Text.debugLine("entry/src/main/ets/components/InfoItem.ets(17:9)");
            Text.fontSize(13);
            Text.fontColor(Color.Gray);
            Text.margin({ top: 10, left: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.itemObj.levelIcon);
            Image.debugLine("entry/src/main/ets/components/InfoItem.ets(21:9)");
            Image.width(20);
            Image.aspectRatio(1);
            Image.margin({ top: 10, left: 8 });
            Image.borderRadius(15);
        }, Image);
        // 1. 头像, 昵称, 等级
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 2. 评论内容
            Text.create(this.itemObj.commentTxt);
            Text.debugLine("entry/src/main/ets/components/InfoItem.ets(27:7)");
            // 2. 评论内容
            Text.fontSize(13);
            // 2. 评论内容
            Text.fontColor(Color.Black);
            // 2. 评论内容
            Text.margin({ left: 40, top: 0, bottom: 8 });
        }, Text);
        // 2. 评论内容
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 3. 评论日期 和 点赞互动
            Row.create();
            Row.debugLine("entry/src/main/ets/components/InfoItem.ets(33:7)");
            // 3. 评论日期 和 点赞互动
            Row.padding({ left: 40, top: 5 });
            // 3. 评论日期 和 点赞互动
            Row.width('100%');
            // 3. 评论日期 和 点赞互动
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemObj.convertTime(this.itemObj.time));
            Text.debugLine("entry/src/main/ets/components/InfoItem.ets(34:9)");
            Text.fontSize(11);
            Text.fontColor(Color.Gray);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/InfoItem.ets(37:9)");
            Row.onClick(() => {
                // 此处的this是子组件
                // 让当前项的 likeNum 变化 (老爹的数据, 需要调用老爹的方法才能改)
                this.onLikeClick(this.index);
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.itemObj.isLike ? { "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.part3comment", "moduleName": "entry" } : { "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.part3comment", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/InfoItem.ets(38:11)");
            Image.width(15);
            Image.aspectRatio(1);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.itemObj.likeNum.toString());
            Text.debugLine("entry/src/main/ets/components/InfoItem.ets(40:11)");
            Text.fontSize(11);
            Text.fontColor(this.itemObj.isLike ? Color.Blue : Color.Gray);
        }, Text);
        Text.pop();
        Row.pop();
        // 3. 评论日期 和 点赞互动
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default InfoItem;
