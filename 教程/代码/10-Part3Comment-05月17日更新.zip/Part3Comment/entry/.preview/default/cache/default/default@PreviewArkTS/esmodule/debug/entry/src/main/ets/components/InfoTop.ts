interface InfoTop_Params {
    isOn?: boolean;
    onSort?;
}
function __Button__fancyButton(isOn: boolean): void {
    Button.width(46);
    Button.height(32);
    Button.fontSize(12);
    Button.padding({ left: 5, right: 5 });
    Button.backgroundColor(isOn ? '#fff' : '#F7F8FA');
    Button.fontColor(isOn ? '#2f2e33' : '#8e9298');
    Button.border({ width: 1, color: isOn ? '#e4e5e6' : '#F7F8FA' });
}
class InfoTop extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isOn = new ObservedPropertySimplePU(true, this, "isOn");
        this.onSort = (type: number) => { };
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: InfoTop_Params) {
        if (params.isOn !== undefined) {
            this.isOn = params.isOn;
        }
        if (params.onSort !== undefined) {
            this.onSort = params.onSort;
        }
    }
    updateStateVars(params: InfoTop_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isOn.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isOn.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isOn: ObservedPropertySimplePU<boolean>;
    get isOn() {
        return this.__isOn.get();
    }
    set isOn(newValue: boolean) {
        this.__isOn.set(newValue);
    }
    private onSort;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/InfoTop.ets(17:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.padding(16);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('全部评论');
            Text.debugLine("entry/src/main/ets/components/InfoTop.ets(18:7)");
            Text.fontColor('#222');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/InfoTop.ets(22:7)");
            Row.backgroundColor('#F7F8FA');
            Row.borderRadius(20);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('最新', { stateEffect: false });
            Button.debugLine("entry/src/main/ets/components/InfoTop.ets(23:9)");
            __Button__fancyButton(this.isOn);
            Button.onClick(() => {
                this.isOn = true;
                this.onSort(0);
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('最热', { stateEffect: false });
            Button.debugLine("entry/src/main/ets/components/InfoTop.ets(29:9)");
            __Button__fancyButton(!this.isOn);
            Button.onClick(() => {
                this.isOn = false;
                this.onSort(1);
            });
        }, Button);
        Button.pop();
        Row.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default InfoTop;
