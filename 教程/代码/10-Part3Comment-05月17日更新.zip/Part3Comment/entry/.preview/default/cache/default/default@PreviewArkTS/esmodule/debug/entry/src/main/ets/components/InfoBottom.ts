interface InfoBottom_Params {
    txt?: string;
    onSubmitComment?;
}
class InfoBottom extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__txt = new ObservedPropertySimplePU('', this, "txt");
        this.onSubmitComment = (content: string) => { };
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: InfoBottom_Params) {
        if (params.txt !== undefined) {
            this.txt = params.txt;
        }
        if (params.onSubmitComment !== undefined) {
            this.onSubmitComment = params.onSubmitComment;
        }
    }
    updateStateVars(params: InfoBottom_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__txt.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__txt.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __txt: ObservedPropertySimplePU<string>;
    get txt() {
        return this.__txt.get();
    }
    set txt(newValue: string) {
        this.__txt.set(newValue);
    }
    private onSubmitComment;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/InfoBottom.ets(7:5)");
            Row.height(60);
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/InfoBottom.ets(8:7)");
            Row.height(40);
            Row.backgroundColor('#f5f6f5');
            Row.borderRadius(20);
            Row.margin({ left: 15, right: 20, top: 10, bottom: 10 });
            Row.layoutWeight(1);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('\ue840');
            Text.debugLine("entry/src/main/ets/components/InfoBottom.ets(9:9)");
            Text.fontFamily('myfont');
            Text.fontSize(18);
            Text.margin({ left: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({
                placeholder: '写评论...',
                text: { value: this.txt, changeEvent: newValue => { this.txt = newValue; } }
            });
            TextInput.debugLine("entry/src/main/ets/components/InfoBottom.ets(13:9)");
            TextInput.backgroundColor(Color.Transparent);
            TextInput.fontSize(18);
            TextInput.onSubmit(() => {
                // 这里不能直接添加, 需要调用父组件传递过来的方法
                this.onSubmitComment(this.txt);
            });
        }, TextInput);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('\ue600');
            Text.debugLine("entry/src/main/ets/components/InfoBottom.ets(30:7)");
            Text.fontFamily('myfont');
            Text.fontSize(26);
            Text.margin({ left: 6, right: 6 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('\ue61d');
            Text.debugLine("entry/src/main/ets/components/InfoBottom.ets(35:7)");
            Text.fontFamily('myfont');
            Text.fontSize(26);
            Text.margin({ left: 6, right: 6 });
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default InfoBottom;
