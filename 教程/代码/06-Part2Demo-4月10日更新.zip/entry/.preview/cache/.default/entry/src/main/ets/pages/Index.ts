interface Index_Params {
    randomIndex?: number;
    images?: ImageCount[];
    maskOpacity?: number;
    maskZIndex?: number;
    maskImgX?: number;
    maskImgY?: number;
    isGet?: boolean;
    arr?: string[];
    prize?: string;
}
// 定义接口 (每个列表项的数据结构)
interface ImageCount {
    url: string;
    count: number;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__randomIndex = new ObservedPropertySimplePU(-1 // 表示还没开始抽
        // 基于接口, 准备数据
        , this, "randomIndex");
        this.__images = new ObservedPropertyObjectPU([
            { url: 'app.media.bg_00', count: 0 },
            { url: 'app.media.bg_01', count: 0 },
            { url: 'app.media.bg_02', count: 0 },
            { url: 'app.media.bg_03', count: 0 },
            { url: 'app.media.bg_04', count: 0 },
            { url: 'app.media.bg_05', count: 0 }
        ]
        // 控制遮罩的显隐
        , this, "images");
        this.__maskOpacity = new ObservedPropertySimplePU(0 // 透明度
        , this, "maskOpacity");
        this.__maskZIndex = new ObservedPropertySimplePU(-1 // 显示层级
        // 控制图片的缩放
        , this, "maskZIndex");
        this.__maskImgX = new ObservedPropertySimplePU(0 // 水平缩放比
        , this, "maskImgX");
        this.__maskImgY = new ObservedPropertySimplePU(0 // 垂直缩放比
        // 控制中大奖遮罩的显隐
        , this, "maskImgY");
        this.__isGet = new ObservedPropertySimplePU(false, this, "isGet");
        this.__arr = new ObservedPropertyObjectPU(['pg', 'hw', 'xm'] // 奖池
        , this, "arr");
        this.__prize = new ObservedPropertySimplePU('' // 默认没中奖
        , this, "prize");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.randomIndex !== undefined) {
            this.randomIndex = params.randomIndex;
        }
        if (params.images !== undefined) {
            this.images = params.images;
        }
        if (params.maskOpacity !== undefined) {
            this.maskOpacity = params.maskOpacity;
        }
        if (params.maskZIndex !== undefined) {
            this.maskZIndex = params.maskZIndex;
        }
        if (params.maskImgX !== undefined) {
            this.maskImgX = params.maskImgX;
        }
        if (params.maskImgY !== undefined) {
            this.maskImgY = params.maskImgY;
        }
        if (params.isGet !== undefined) {
            this.isGet = params.isGet;
        }
        if (params.arr !== undefined) {
            this.arr = params.arr;
        }
        if (params.prize !== undefined) {
            this.prize = params.prize;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__randomIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__images.purgeDependencyOnElmtId(rmElmtId);
        this.__maskOpacity.purgeDependencyOnElmtId(rmElmtId);
        this.__maskZIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__maskImgX.purgeDependencyOnElmtId(rmElmtId);
        this.__maskImgY.purgeDependencyOnElmtId(rmElmtId);
        this.__isGet.purgeDependencyOnElmtId(rmElmtId);
        this.__arr.purgeDependencyOnElmtId(rmElmtId);
        this.__prize.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__randomIndex.aboutToBeDeleted();
        this.__images.aboutToBeDeleted();
        this.__maskOpacity.aboutToBeDeleted();
        this.__maskZIndex.aboutToBeDeleted();
        this.__maskImgX.aboutToBeDeleted();
        this.__maskImgY.aboutToBeDeleted();
        this.__isGet.aboutToBeDeleted();
        this.__arr.aboutToBeDeleted();
        this.__prize.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 随机的生肖卡序号 0-5
    private __randomIndex: ObservedPropertySimplePU<number>; // 表示还没开始抽
    get randomIndex() {
        return this.__randomIndex.get();
    }
    set randomIndex(newValue: number) {
        this.__randomIndex.set(newValue);
    }
    // 基于接口, 准备数据
    private __images: ObservedPropertyObjectPU<ImageCount[]>;
    get images() {
        return this.__images.get();
    }
    set images(newValue: ImageCount[]) {
        this.__images.set(newValue);
    }
    // 控制遮罩的显隐
    private __maskOpacity: ObservedPropertySimplePU<number>; // 透明度
    get maskOpacity() {
        return this.__maskOpacity.get();
    }
    set maskOpacity(newValue: number) {
        this.__maskOpacity.set(newValue);
    }
    private __maskZIndex: ObservedPropertySimplePU<number>; // 显示层级
    get maskZIndex() {
        return this.__maskZIndex.get();
    }
    set maskZIndex(newValue: number) {
        this.__maskZIndex.set(newValue);
    }
    // 控制图片的缩放
    private __maskImgX: ObservedPropertySimplePU<number>; // 水平缩放比
    get maskImgX() {
        return this.__maskImgX.get();
    }
    set maskImgX(newValue: number) {
        this.__maskImgX.set(newValue);
    }
    private __maskImgY: ObservedPropertySimplePU<number>; // 垂直缩放比
    get maskImgY() {
        return this.__maskImgY.get();
    }
    set maskImgY(newValue: number) {
        this.__maskImgY.set(newValue);
    }
    // 控制中大奖遮罩的显隐
    private __isGet: ObservedPropertySimplePU<boolean>;
    get isGet() {
        return this.__isGet.get();
    }
    set isGet(newValue: boolean) {
        this.__isGet.set(newValue);
    }
    private __arr: ObservedPropertyObjectPU<string[]>; // 奖池
    get arr() {
        return this.__arr.get();
    }
    set arr(newValue: string[]) {
        this.__arr.set(newValue);
    }
    private __prize: ObservedPropertySimplePU<string>; // 默认没中奖
    get prize() {
        return this.__prize.get();
    }
    set prize(newValue: string) {
        this.__prize.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(44:5)");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 初始化的布局结构
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(46:7)");
            // 初始化的布局结构
            Column.width('100%');
            // 初始化的布局结构
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/Index.ets(47:9)");
            Grid.columnsTemplate('1fr 1fr 1fr');
            Grid.rowsTemplate('1fr 1fr');
            Grid.width('100%');
            Grid.height(300);
            Grid.margin({ top: 100 });
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.debugLine("entry/src/main/ets/pages/Index.ets(49:13)");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Badge.create({
                                count: item.count,
                                position: BadgePosition.RightTop,
                                style: {
                                    fontSize: 14,
                                    badgeSize: 20,
                                    badgeColor: '#fa2a2d'
                                }
                            });
                            Badge.debugLine("entry/src/main/ets/pages/Index.ets(50:15)");
                        }, Badge);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create({ "id": item.url, params: [], "bundleName": "com.example.part2demo", "moduleName": "entry" });
                            Image.debugLine("entry/src/main/ets/pages/Index.ets(59:17)");
                            Image.width(80);
                        }, Image);
                        Badge.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.images, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        Grid.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('立即抽卡');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(71:9)");
            Button.width(200);
            Button.backgroundColor('#ed5b8c');
            Button.margin({ top: 50 });
            Button.onClick(() => {
                // 点击时, 修改遮罩参数, 让遮罩显示
                this.maskOpacity = 1;
                this.maskZIndex = 99;
                // 点击时, 图片需要缩放
                this.maskImgX = 1;
                this.maskImgY = 1;
                // 计算随机数 Math.random()  [0,1) * (n + 1)
                this.randomIndex = Math.floor(Math.random() * 6);
            });
        }, Button);
        Button.pop();
        // 初始化的布局结构
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 抽卡遮罩层 (弹层)
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(91:7)");
            Context.animation({
                duration: 200
            });
            // 抽卡遮罩层 (弹层)
            Column.justifyContent(FlexAlign.Center);
            // 抽卡遮罩层 (弹层)
            Column.width('100%');
            // 抽卡遮罩层 (弹层)
            Column.height('100%');
            // 抽卡遮罩层 (弹层)
            Column.backgroundColor('#cc000000');
            // 抽卡遮罩层 (弹层)
            Column.opacity(this.maskOpacity);
            // 抽卡遮罩层 (弹层)
            Column.zIndex(this.maskZIndex);
            Context.animation(null);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('获得生肖卡');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(92:9)");
            Text.fontColor('#f5ebcf');
            Text.fontSize(25);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": `app.media.img_0${this.randomIndex}`, params: [], "bundleName": "com.example.part2demo", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(96:9)");
            Context.animation({
                duration: 500
            });
            Image.width(200);
            Image.scale({
                x: this.maskImgX,
                y: this.maskImgY
            });
            Context.animation(null);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('开心收下');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(106:9)");
            Button.width(200);
            Button.height(50);
            Button.backgroundColor(Color.Transparent);
            Button.border({ width: 2, color: '#fff9e0' });
            Button.onClick(() => {
                // 控制弹层显隐
                this.maskOpacity = 0;
                this.maskZIndex = -1;
                // 图像重置缩放比为 0
                this.maskImgX = 0;
                this.maskImgY = 0;
                // 开心收下, 对象数组的情况需要更新, 需要修改替换整个对象
                // this.images[this.randomIndex].count++
                this.images[this.randomIndex] = {
                    url: `app.media.img_0${this.randomIndex}`,
                    count: this.images[this.randomIndex].count + 1
                };
                // 每次收完卡片, 需要进行简单的检索, 判断是否集齐
                // 需求: 判断数组项的count, 是否都大于0, 只要有一个等于0,就意味着没集齐
                let flag: boolean = true; // 假设集齐
                // 验证是否集齐
                for (let item of this.images) {
                    if (item.count == 0) {
                        flag = false; // 没集齐
                        break; // 后面的没必要判断了
                    }
                }
                this.isGet = flag;
                // 判断是否中奖了, 如果是 需要抽奖
                if (flag) {
                    let randomIndex: number = Math.floor(Math.random() * 3);
                    this.prize = this.arr[randomIndex];
                }
            });
        }, Button);
        Button.pop();
        // 抽卡遮罩层 (弹层)
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 抽大奖的遮罩层
            if (this.isGet) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 30 });
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(163:9)");
                        Column.justifyContent(FlexAlign.Center);
                        Column.width('100%');
                        Column.height('100%');
                        Column.backgroundColor('#cc000000');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('恭喜获得手机一部');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(164:11)");
                        Text.fontColor('#f5ebcf');
                        Text.fontSize(25);
                        Text.fontWeight(700);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": `app.media.${this.prize}`, params: [], "bundleName": "com.example.part2demo", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/Index.ets(168:11)");
                        Image.width(300);
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('再来一次');
                        Button.debugLine("entry/src/main/ets/pages/Index.ets(170:11)");
                        Button.width(200);
                        Button.height(50);
                        Button.backgroundColor(Color.Transparent);
                        Button.border({ width: 2, color: '#fff9e0' });
                        Button.onClick(() => {
                            this.isGet = false;
                            this.prize = '';
                            this.images = [
                                { url: 'app.media.bg_00', count: 0 },
                                { url: 'app.media.bg_01', count: 0 },
                                { url: 'app.media.bg_02', count: 0 },
                                { url: 'app.media.bg_03', count: 0 },
                                { url: 'app.media.bg_04', count: 0 },
                                { url: 'app.media.bg_05', count: 0 }
                            ];
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.part2demo", moduleName: "entry", pagePath: "pages/Index" });
