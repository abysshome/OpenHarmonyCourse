interface DetailPage_Params {
}
import router from "@ohos:router";
class DetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: DetailPage_Params) {
    }
    updateStateVars(params: DetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DetailPage.ets(7:5)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('详情页面');
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(8:7)");
            Text.fontSize(80);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('跳转');
            Button.debugLine("entry/src/main/ets/pages/DetailPage.ets(10:7)");
            Button.onClick(() => {
                router.pushUrl({
                    url: 'pages/EditPage'
                }, router.RouterMode.Single);
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('获取页面栈长度');
            Button.debugLine("entry/src/main/ets/pages/DetailPage.ets(16:7)");
            Button.onClick(() => {
                AlertDialog.show({
                    message: router.getLength()
                });
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DetailPage";
    }
}
registerNamedRoute(() => new DetailPage(undefined, {}), "", { bundleName: "com.example.part4demo", moduleName: "entry", pagePath: "pages/DetailPage" });
